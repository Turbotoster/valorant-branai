#ifndef OFFSETS_H
#define OFFSETS_H
#include <cstdint>

namespace offsets
{
    constexpr uint64_t UWorld_State = 0x9015500;

    constexpr uint64_t UWorld_Key = UWorld_State + 0x38;

    constexpr uint64_t Override_Materials = 0x4f8;

    constexpr uint64_t GameInstance = 0x1A8;

    constexpr uint64_t PersistentLevel = 0x38;

    constexpr uint64_t LocalPlayer_Array = 0x40;

    constexpr uint64_t LocalPlayer_Controller = 0x38;

    constexpr uint64_t LocalPlayer_Pawn = 0x460;

    constexpr uint64_t ControlRotation = 0x440;

    constexpr uint64_t CameraManager = 0x478;

    constexpr uint64_t CameraPosition = 0x1240;

    constexpr uint64_t CameraRotation = 0x124C;

    constexpr uint64_t CameraFOV = 0x1258;

    constexpr uint64_t Actor_Array = 0xA0;

    constexpr uint64_t ActorCount = 0xB8;

    constexpr uint64_t UniqueId = 0x38;

    constexpr uint64_t MeshComponent = 0x430;

    constexpr uint64_t LastRenderTime = 0x350;

    constexpr uint64_t LastSubmitTime = 0x358;

    constexpr uint64_t Bone_Array = 0x558;

    constexpr uint64_t BoneCount = 0x560; // MAY BE OUTDATED

    constexpr uint64_t ComponentToWorld = 0x250;

    constexpr uint64_t RootComponent = 0x230;

    constexpr uint64_t RootPosition = 0x164;

    constexpr uint64_t DamageHandler = 0x9A0;

    constexpr uint64_t Health = 0x1B0;

    constexpr uint64_t Dormant = 0x120;

    constexpr uint64_t PlayerState = 0x3F0;

    constexpr uint64_t TeamComponent = 0x5A0;

    constexpr uint64_t TeamID = 0xF8;

    constexpr auto FresnelIntensity = 0x6B8;

    constexpr auto FresnelOffset = 0x694;

    constexpr auto CachedFresnelColor = 0x680;

    constexpr auto CachedFresnelOffset = 0x684;

    constexpr auto CachedFresnelIntensity = 0x688;

    constexpr auto CachedLocalFresnelOffset = 0x68c;

    constexpr auto LineOfSight = 0x4A60CE0;

}
#endif
