#ifndef VECTOR_3_H
#define VECTOR_3_H
#include <d3d9.h>
#include <math.h>
#define UCONST_Pi 3.1415926535
#define RadianToURotation 180.0f / UCONST_Pi

class Vector3 {

public:

    // -------------------- Attributes -------------------- //

    // Components of the vector
    float x, y, z;

    // -------------------- Methods -------------------- //

    // Constructor
    Vector3(float x = 0, float y = 0, float z = 0);

    // Constructor
    Vector3(const Vector3& vector);

    // Constructor
    ~Vector3();

    // = operator
    Vector3& operator=(const Vector3& vector);

    // + operator
    Vector3 operator+(const Vector3& v) const;

    // += operator
    Vector3& operator+=(const Vector3& v);

    // - operator
    Vector3 operator-(const Vector3& v) const;

    // -= operator
    Vector3& operator-=(const Vector3& v);

    // == operator
    bool operator==(const Vector3& v) const;

    // != operator
    bool operator!=(const Vector3& v) const;

    // * operator
    Vector3 operator*(float f) const;

    // *= operator
    Vector3& operator*=(float f);

    // / operator
    Vector3 operator/(float f) const;

    // /= operator
    Vector3& operator/=(float f);

    // - operator
    Vector3 operator-() const;

    // [] operator
    float& operator[](int i);

    // [] operator
    const float& operator[](int i) const;

    // Cross product operator
    Vector3 cross(const Vector3& v) const;

    // Dot product operator
    float dot(const Vector3& v) const;

    // Normalize the vector and return it
    Vector3 normalize();

    bool isNull() const;

    // Clamp the values between 0 and 1
    Vector3 clamp01();

    inline float Distance(Vector3 v) {
        return float(sqrtf(powf(v.x - x, 2.0) + powf(v.y - y, 2.0) + powf(v.z - z, 2.0)));
    }

    inline float Dot(Vector3 v) {
        return x * v.x + y * v.y + z * v.z;
    }


    // Return the squared length of the vector
    float lengthSquared() const;

    // Return the length of the vector
    float length() const;
};


struct Vector2 {
public:
    float x;
    float y;

    inline Vector2() : x(0), y(0) {}
    inline Vector2(float x, float y) : x(x), y(y) {}

    inline float Distance(Vector2 v) {
        return sqrtf(((v.x - x) * (v.x - x) + (v.y - y) * (v.y - y)));
    }

    inline Vector2 operator+(const Vector2& v) const;

    inline Vector2 operator-(const Vector2& v) const;
};

struct FQuat {
    float x;
    float y;
    float z;
    float w;
};

struct FTransform {
    FQuat rot;
    Vector3 translation;
    char pad[4]; // 0x123C
    Vector3 scale;
    char pad1[4]; // 0x1244
    D3DMATRIX ToMatrixWithScale();
};

struct FMinimalViewInfo
{
    Vector3 Location; //+ 0x1260
    Vector3 Rotation; //+ 0x126C
    float FOV;     //+ 0x1278
};

class FRotator
{
public:
    float Pitch; //+ 0x122C
    float Yaw; //

	float Roll = 0.f;

	D3DMATRIX GetAxes() {
		auto tempMatrix = Matrix();
		return tempMatrix;
	}

	D3DMATRIX Matrix(Vector3 origin = Vector3(0, 0, 0)) {
		float radPitch = (Pitch * float(UCONST_Pi) / 180.f);
		float radYaw = (Yaw * float(UCONST_Pi) / 180.f);
		float radRoll = (Roll * float(UCONST_Pi) / 180.f);
		float SP = sinf(radPitch);
		float CP = cosf(radPitch);
		float SY = sinf(radYaw);
		float CY = cosf(radYaw);
		float SR = sinf(radRoll);
		float CR = cosf(radRoll);

		D3DMATRIX matrix;
		matrix.m[0][0] = CP * CY;
		matrix.m[0][1] = CP * SY;
		matrix.m[0][2] = SP;
		matrix.m[0][3] = 0.f;

		matrix.m[1][0] = SR * SP * CY - CR * SY;
		matrix.m[1][1] = SR * SP * SY + CR * CY;
		matrix.m[1][2] = -SR * CP;
		matrix.m[1][3] = 0.f;

		matrix.m[2][0] = -(CR * SP * CY + SR * SY);
		matrix.m[2][1] = CY * SR - CR * SP * SY;
		matrix.m[2][2] = CR * CP;
		matrix.m[2][3] = 0.f;

		matrix.m[3][0] = origin.x;
		matrix.m[3][1] = origin.y;
		matrix.m[3][2] = origin.z;
		matrix.m[3][3] = 1.f;

		return matrix;
	}
};
#endif